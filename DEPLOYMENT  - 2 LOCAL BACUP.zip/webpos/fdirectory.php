<?php

require_once "appserv/classes/class.directory.php";
require_once "appserv/classes/view.class.php";