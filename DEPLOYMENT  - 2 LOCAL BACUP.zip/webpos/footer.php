<div class="footer-wrapper">
    <div class="footer-container">
        <div class="footer-main">
            <p>Copyright © <?php echo date('Y');?>, Jtolentin Development. All Rights Reserved</p>
        </div>
    </div>
</div>