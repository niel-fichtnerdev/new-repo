<div class="graph_contianer">
    <div class="graph_curve">
        <canvas id="myChart"></canvas>
        <canvas id="myChart2"></canvas>
        <div class="graph-details">
            <h4>Grand Sales Summary</h4>
            <p><?php echo date('M');?> (This Month): <b id="currentMonthSales">0.00</b></p>
            <p>NRGT: <b id="presentnrgt">0.00</b></p>
            <p>Average gross/Month: <b id="avesales">0.00</b></p>
            <p>Expenses (<?php echo date('M');?>): <b>0.00</b></p>
            <p>Terminal with highest gross: <b>0001</b></p>
        </div>
    </div>

</div>

<script type="text/javascript" src="js/custom.js"></script>