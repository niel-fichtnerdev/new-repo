<?php

if (!defined('BASE')) define('BASE', dirname(__FILE__) ."/../");
 

require BASE.'/classes/model.class.php';


class authenticate extends Dbh{
    
    public function auth(){

    }
}

