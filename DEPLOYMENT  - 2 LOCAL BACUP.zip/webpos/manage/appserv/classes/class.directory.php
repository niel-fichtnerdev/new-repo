<?php

require 'controller.class.php';
require 'view.class.php';