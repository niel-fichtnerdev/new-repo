<!-- Add terminal -->

<div class="cmodal_wrapper" id="add-product">
    <div class="cmodal_container">
        
              <!-- Modal content -->
                <div class="ccontent">
                    <div class="close_bar">
                        <span class="c-close">&#128469;</span>
                    </div>
                    
                    <div class="ctitle">
                        <h2>New Terminal</h2>
                    </div>
                    <div class="cmain">      
                        <!-- CONTENT HERE -->
                        <h1 style="color:black">
                        <i class="fa fa-cogs" aria-hidden="true"></i> This module is still being developed to offer you even more capabilities. Keep an eye out for updates!</h1>
                        <br>
                        <p style="color: black"><strong>Note: It's important to acknowledge that the current system release is set up to support a solitary terminal in operation</strong></p>
                        <p style="color: black"><strong>If you need additional details:</strong> Feel free to reach me out via email at tolentin.joseniel@gmail.com</p>
                        <p style="color: black">Release Version:Demo V1.0.0.30</p>

                        
                    </div>
                    <div class="cfooter">
                        <button type="submit" class="submit-button" id="modal_close"><i class="fa fa-check" aria-hidden="true"></i>

Add </button>
                        <button type="button" class="cbutton" id="clear-input"><i class="fa fa-times" aria-hidden="true"></i>
Cancel</button>
                
                    </div>
                    
                </div>
        </div>
    
</div>
