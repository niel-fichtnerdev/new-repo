<!-- Income Summary Modal -->

<div class="cmodal_wrapper" id="income_modal">
    <div class="cmodal_container">

        <!-- Modal content -->
        <div class="ccontent">
            <div class="close_bar">
                <span class="c-close">&times;</span>
            </div>

            <div class="ctitle">

                <h2 id="sales_header"></h2>

                <h2 id="sales_headerright"></h2>
            </div>

            <div class="cmain">
                <div class="sales_table">
                    <table class="table-data" id="salesdata">

                        <tr>
            

                        </tr>
                    </table>
                </div>

            </div>
            <div class="cfooter">
                <button class="cbutton" id="trxexcel"><i class="fa fa-table" aria-hidden="true"></i>Excel</button>
                <button class="cbutton"><i class="" aria-hidden="true"></i>Close</button>
            </div>

        </div>
    </div>

</div>