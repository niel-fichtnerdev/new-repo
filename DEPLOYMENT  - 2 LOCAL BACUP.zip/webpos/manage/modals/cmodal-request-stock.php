<!-- Request stock -->

<div class="cmodal_wrapper" id="frequest_stock">
    <div class="cmodal_container">
        
              <!-- Modal content -->
                <div class="ccontent">
                    <div class="close_bar">
                        <span class="c-close">&times;</span>
                    </div>
                    
                    <div class="ctitle">
                        <h2>Request Stock</h2>
                    </div>
                    <div class="cmain">      
                        <!-- CONTENT HERE -->
                    </div>
                    <div class="cfooter">
                        <button class="cbutton" id="modal_close"><i class="fa fa-check" aria-hidden="true"></i>

Save</button>
                        <button class="cbutton"><i class="fa fa-times" aria-hidden="true"></i>
Cancel</button>
                    </div>
                    
                </div>
        </div>
    
</div>

