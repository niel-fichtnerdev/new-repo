<!-- Terminal Master -->

<div class="cmodal_wrapper" id="terminal-master">
    <div class="cmodal_container">
        
              <!-- Modal content -->
                <div class="ccontent">
                    <div class="close_bar">
                        <span class="c-close">&times;</span>
                    </div>
                    
                    <div class="ctitle">
                        <h2>Terminal Master</h2>
                    </div>
                    <div class="cmain">      
                    <h1 style="color:black">
                        <i class="fa fa-cogs" aria-hidden="true"></i> Work in Progress: This module is still being developed to offer you even more capabilities. Keep an eye out for updates!</h1>

                        <br>
                        <p style="color: black"><strong>Note: It's important to acknowledge that the current system release is set up to support a solitary terminal in operation</strong></p>
                        <p style="color: black"><strong>If you need additional details:</strong> Feel free to reach me out via email at tolentin.joseniel@gmail.com</p>
                        <p style="color: black">Release Version:Demo V1.0.0.30</p>
                    </div>
                    <div class="cfooter">
                        <button class="cbutton" id="modal_close"><i class="fa fa-check" aria-hidden="true"></i>

Save</button>
                        <button class="cbutton"><i class="fa fa-times" aria-hidden="true"></i>
Cancel</button>
                    </div>
                    
                </div>
        </div>
    
</div>

