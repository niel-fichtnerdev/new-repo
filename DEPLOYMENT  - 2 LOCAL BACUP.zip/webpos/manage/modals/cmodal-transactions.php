<!-- Transaction List -->

<div class="cmodal_wrapper" id="view-transactions">
    <div class="cmodal_container">
        
              <!-- Modal content -->
                <div class="ccontent">
                    <div class="close_bar">
                        <span class="c-close">&times;</span>
                    </div>
                    
                    <div class="ctitle">
                        <h2>Current Transaction List</h2>
                    </div>
                    <div class="cmain">      
                        <!-- CONTENT HERE -->
                        <div class="sales_table">
                            <table class="table-data" id="currenttrx">
                            <tr>
            

                            </tr>
                            </table>
                        </div>
                    </div>
                    <div class="cfooter">
                    <button class="cbutton" id="trxexcel"><i class="fa fa-table" aria-hidden="true"></i>Excel</button>
                <button class="cbutton"><i class="" aria-hidden="true"></i>Close</button>
                    </div>
                    
                </div>
        </div>
    
</div>

