<!-- Add Category -->

<script>
    
</script>

<div class="cmodal_wrapper" id="settledialog">
    <div class="cmodal_container">
        
              <!-- Modal content -->
                <div class="ccontent">
                    <div class="close_bar">
                        <span class="c-close">&#128469;</span>
                    </div>
                    
                    <div class="ctitle">
                        <h2>Please Enter Cash</h2>
                    </div>
                    <div class="cmain">      

               
                    </div>
                    <div class="cfooter">
                        <button type="submit" class="submit-button" id="modal_close"><i class="fa fa-check" aria-hidden="true"></i>

Add </button>
                        <button type="button" class="cbutton" id="clear-input"><i class="fa fa-times" aria-hidden="true"></i>
Cancel</button>
                
                    </div>
                    
                </div>
        </div>
    
</div>


























