<?php
echo $_POST['user_name'];
echo 'user saved';