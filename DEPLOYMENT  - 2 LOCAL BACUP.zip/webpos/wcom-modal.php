<!-- Welcome Modal -->
<div class="wmodal-wrapper">
    <div class="wmodal-container">
        <div class="wmodal">
            <div class="wmodal-header">
                <!-- Header -->
                <p>This is header</p>
            </div>

            <div class="wmodal-content">
                <!-- content -->
                <p>this is the content</p>
            </div>

            <div class="wmodal-footer">
                <!-- Footer -->
                <p>this is the footer</p>
            </div>
        </div>
    </div>
</div>


